﻿namespace Bitirme_Projesi
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxEvrakteslimEdildimi = new System.Windows.Forms.CheckBox();
            this.comboBoxbasaiKontrol = new System.Windows.Forms.ComboBox();
            this.textboxKayitNo = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.richTextBoxAciklama = new System.Windows.Forms.RichTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBoxStajRaporu = new System.Windows.Forms.CheckBox();
            this.checkBoxStajDegerlendirmeFormu = new System.Windows.Forms.CheckBox();
            this.checkBoxKimlikFotokopisiVerildimi = new System.Windows.Forms.CheckBox();
            this.checkBoxMustehaklikBelgesiVerildimi = new System.Windows.Forms.CheckBox();
            this.checkBoxKabulYazısıGetirildimi = new System.Windows.Forms.CheckBox();
            this.checkBoxBasvuruDilekcesiVerildimi = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBoxEnd300400Kodu = new System.Windows.Forms.TextBox();
            this.textBoxZorunluStajYazısıKodu = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dateTimePickerStajBitisTarihi = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerBaslangicTarihi = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBoxStajKodu = new System.Windows.Forms.ComboBox();
            this.textBoxStajYeri = new System.Windows.Forms.TextBox();
            this.textBoxEPosta = new System.Windows.Forms.TextBox();
            this.textBoxCepTelNo = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxSinifi = new System.Windows.Forms.ComboBox();
            this.textBoxOgrNo = new System.Windows.Forms.TextBox();
            this.textBoxSoyad = new System.Windows.Forms.TextBox();
            this.textBoxAd = new System.Windows.Forms.TextBox();
            this.textBoxTcNo = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttonCikis = new System.Windows.Forms.Button();
            this.buttonTemizle = new System.Windows.Forms.Button();
            this.buttonKaydetGuncelle = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBoxogretmen = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(15, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kayıt No";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(15, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "T.C. Kimlik No";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(15, 50);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ad";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(15, 89);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Soyad";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(15, 124);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Öğrenci No";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(15, 158);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Sınıfı";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(15, 38);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Cep Tel No";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(15, 72);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "E Posta";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(15, 107);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(158, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Staj Kodu";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Maroon;
            this.label10.Location = new System.Drawing.Point(15, 145);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(158, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Staj Yeri";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.Maroon;
            this.label11.Location = new System.Drawing.Point(15, 29);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(179, 19);
            this.label11.TabIndex = 10;
            this.label11.Text = "Staj Başlangıç Tarihi";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Maroon;
            this.label12.Location = new System.Drawing.Point(15, 65);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(158, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Staj Bitiş Tarihi";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Maroon;
            this.label13.Location = new System.Drawing.Point(19, 210);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(286, 20);
            this.label13.TabIndex = 20;
            this.label13.Text = "Staj Raporu Verildi mi?";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.Maroon;
            this.label14.Location = new System.Drawing.Point(19, 175);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(286, 20);
            this.label14.TabIndex = 19;
            this.label14.Text = "Staj Değerlendirme Formu Getirildi mi?";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.Maroon;
            this.label15.Location = new System.Drawing.Point(19, 136);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(286, 20);
            this.label15.TabIndex = 18;
            this.label15.Text = "Kimlik Fotokopisi Verildi mi?";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.Maroon;
            this.label16.Location = new System.Drawing.Point(19, 100);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(286, 20);
            this.label16.TabIndex = 17;
            this.label16.Text = "Müstehaklık Belgesi Verildi mi?";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.Maroon;
            this.label17.Location = new System.Drawing.Point(19, 61);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(286, 20);
            this.label17.TabIndex = 16;
            this.label17.Text = "Kabul Yazısı Getirildi mi?";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.Maroon;
            this.label18.Location = new System.Drawing.Point(19, 24);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(286, 20);
            this.label18.TabIndex = 15;
            this.label18.Text = "Başvuru Dilekçesi Verildi mi?";
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.Maroon;
            this.label19.Location = new System.Drawing.Point(19, 61);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(286, 20);
            this.label19.TabIndex = 14;
            this.label19.Text = "END300/400 Yazısı";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.Maroon;
            this.label20.Location = new System.Drawing.Point(19, 24);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(286, 20);
            this.label20.TabIndex = 13;
            this.label20.Text = "Zorunlu Staj Yazısı";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.Maroon;
            this.label21.Location = new System.Drawing.Point(526, 22);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(359, 19);
            this.label21.TabIndex = 12;
            this.label21.Text = "Staj Evrakları Personele Teslim Edildi mi?";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.comboBoxogretmen);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(11, 22);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(1058, 828);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // checkBoxEvrakteslimEdildimi
            // 
            this.checkBoxEvrakteslimEdildimi.AutoSize = true;
            this.checkBoxEvrakteslimEdildimi.Location = new System.Drawing.Point(929, 21);
            this.checkBoxEvrakteslimEdildimi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxEvrakteslimEdildimi.Name = "checkBoxEvrakteslimEdildimi";
            this.checkBoxEvrakteslimEdildimi.Size = new System.Drawing.Size(15, 14);
            this.checkBoxEvrakteslimEdildimi.TabIndex = 28;
            this.checkBoxEvrakteslimEdildimi.UseVisualStyleBackColor = true;
            // 
            // comboBoxbasaiKontrol
            // 
            this.comboBoxbasaiKontrol.FormattingEnabled = true;
            this.comboBoxbasaiKontrol.Items.AddRange(new object[] {
            "Başarısız",
            "Başarılı"});
            this.comboBoxbasaiKontrol.Location = new System.Drawing.Point(257, 18);
            this.comboBoxbasaiKontrol.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxbasaiKontrol.Name = "comboBoxbasaiKontrol";
            this.comboBoxbasaiKontrol.Size = new System.Drawing.Size(110, 21);
            this.comboBoxbasaiKontrol.TabIndex = 15;
            // 
            // textboxKayitNo
            // 
            this.textboxKayitNo.Location = new System.Drawing.Point(184, 18);
            this.textboxKayitNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textboxKayitNo.Name = "textboxKayitNo";
            this.textboxKayitNo.ReadOnly = true;
            this.textboxKayitNo.Size = new System.Drawing.Size(49, 20);
            this.textboxKayitNo.TabIndex = 27;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox7.Controls.Add(this.richTextBoxAciklama);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Location = new System.Drawing.Point(536, 588);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox7.Size = new System.Drawing.Size(507, 172);
            this.groupBox7.TabIndex = 26;
            this.groupBox7.TabStop = false;
            // 
            // richTextBoxAciklama
            // 
            this.richTextBoxAciklama.Location = new System.Drawing.Point(4, 37);
            this.richTextBoxAciklama.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBoxAciklama.Name = "richTextBoxAciklama";
            this.richTextBoxAciklama.Size = new System.Drawing.Size(500, 126);
            this.richTextBoxAciklama.TabIndex = 28;
            this.richTextBoxAciklama.Text = "";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.Maroon;
            this.label22.Location = new System.Drawing.Point(4, 15);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(500, 20);
            this.label22.TabIndex = 27;
            this.label22.Text = "Açıklama";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox6.Controls.Add(this.checkBoxStajRaporu);
            this.groupBox6.Controls.Add(this.checkBoxStajDegerlendirmeFormu);
            this.groupBox6.Controls.Add(this.checkBoxKimlikFotokopisiVerildimi);
            this.groupBox6.Controls.Add(this.checkBoxMustehaklikBelgesiVerildimi);
            this.groupBox6.Controls.Add(this.checkBoxKabulYazısıGetirildimi);
            this.groupBox6.Controls.Add(this.checkBoxBasvuruDilekcesiVerildimi);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Location = new System.Drawing.Point(536, 274);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox6.Size = new System.Drawing.Size(507, 245);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            // 
            // checkBoxStajRaporu
            // 
            this.checkBoxStajRaporu.AutoSize = true;
            this.checkBoxStajRaporu.Location = new System.Drawing.Point(422, 214);
            this.checkBoxStajRaporu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxStajRaporu.Name = "checkBoxStajRaporu";
            this.checkBoxStajRaporu.Size = new System.Drawing.Size(15, 14);
            this.checkBoxStajRaporu.TabIndex = 26;
            this.checkBoxStajRaporu.UseVisualStyleBackColor = true;
            // 
            // checkBoxStajDegerlendirmeFormu
            // 
            this.checkBoxStajDegerlendirmeFormu.AutoSize = true;
            this.checkBoxStajDegerlendirmeFormu.Location = new System.Drawing.Point(422, 181);
            this.checkBoxStajDegerlendirmeFormu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxStajDegerlendirmeFormu.Name = "checkBoxStajDegerlendirmeFormu";
            this.checkBoxStajDegerlendirmeFormu.Size = new System.Drawing.Size(15, 14);
            this.checkBoxStajDegerlendirmeFormu.TabIndex = 25;
            this.checkBoxStajDegerlendirmeFormu.UseVisualStyleBackColor = true;
            // 
            // checkBoxKimlikFotokopisiVerildimi
            // 
            this.checkBoxKimlikFotokopisiVerildimi.AutoSize = true;
            this.checkBoxKimlikFotokopisiVerildimi.Location = new System.Drawing.Point(422, 136);
            this.checkBoxKimlikFotokopisiVerildimi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxKimlikFotokopisiVerildimi.Name = "checkBoxKimlikFotokopisiVerildimi";
            this.checkBoxKimlikFotokopisiVerildimi.Size = new System.Drawing.Size(15, 14);
            this.checkBoxKimlikFotokopisiVerildimi.TabIndex = 24;
            this.checkBoxKimlikFotokopisiVerildimi.UseVisualStyleBackColor = true;
            // 
            // checkBoxMustehaklikBelgesiVerildimi
            // 
            this.checkBoxMustehaklikBelgesiVerildimi.AutoSize = true;
            this.checkBoxMustehaklikBelgesiVerildimi.Location = new System.Drawing.Point(422, 100);
            this.checkBoxMustehaklikBelgesiVerildimi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxMustehaklikBelgesiVerildimi.Name = "checkBoxMustehaklikBelgesiVerildimi";
            this.checkBoxMustehaklikBelgesiVerildimi.Size = new System.Drawing.Size(15, 14);
            this.checkBoxMustehaklikBelgesiVerildimi.TabIndex = 23;
            this.checkBoxMustehaklikBelgesiVerildimi.UseVisualStyleBackColor = true;
            // 
            // checkBoxKabulYazısıGetirildimi
            // 
            this.checkBoxKabulYazısıGetirildimi.AutoSize = true;
            this.checkBoxKabulYazısıGetirildimi.Location = new System.Drawing.Point(422, 63);
            this.checkBoxKabulYazısıGetirildimi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxKabulYazısıGetirildimi.Name = "checkBoxKabulYazısıGetirildimi";
            this.checkBoxKabulYazısıGetirildimi.Size = new System.Drawing.Size(15, 14);
            this.checkBoxKabulYazısıGetirildimi.TabIndex = 22;
            this.checkBoxKabulYazısıGetirildimi.UseVisualStyleBackColor = true;
            // 
            // checkBoxBasvuruDilekcesiVerildimi
            // 
            this.checkBoxBasvuruDilekcesiVerildimi.AutoSize = true;
            this.checkBoxBasvuruDilekcesiVerildimi.Location = new System.Drawing.Point(422, 30);
            this.checkBoxBasvuruDilekcesiVerildimi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxBasvuruDilekcesiVerildimi.Name = "checkBoxBasvuruDilekcesiVerildimi";
            this.checkBoxBasvuruDilekcesiVerildimi.Size = new System.Drawing.Size(15, 14);
            this.checkBoxBasvuruDilekcesiVerildimi.TabIndex = 21;
            this.checkBoxBasvuruDilekcesiVerildimi.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox5.Controls.Add(this.textBoxEnd300400Kodu);
            this.groupBox5.Controls.Add(this.textBoxZorunluStajYazısıKodu);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Location = new System.Drawing.Point(533, 128);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox5.Size = new System.Drawing.Size(507, 96);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            // 
            // textBoxEnd300400Kodu
            // 
            this.textBoxEnd300400Kodu.Location = new System.Drawing.Point(418, 64);
            this.textBoxEnd300400Kodu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEnd300400Kodu.Name = "textBoxEnd300400Kodu";
            this.textBoxEnd300400Kodu.Size = new System.Drawing.Size(76, 20);
            this.textBoxEnd300400Kodu.TabIndex = 16;
            // 
            // textBoxZorunluStajYazısıKodu
            // 
            this.textBoxZorunluStajYazısıKodu.Location = new System.Drawing.Point(418, 28);
            this.textBoxZorunluStajYazısıKodu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxZorunluStajYazısıKodu.Name = "textBoxZorunluStajYazısıKodu";
            this.textBoxZorunluStajYazısıKodu.Size = new System.Drawing.Size(76, 20);
            this.textBoxZorunluStajYazısıKodu.TabIndex = 15;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox4.Controls.Add(this.dateTimePickerStajBitisTarihi);
            this.groupBox4.Controls.Add(this.dateTimePickerBaslangicTarihi);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Location = new System.Drawing.Point(14, 689);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox4.Size = new System.Drawing.Size(484, 126);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            // 
            // dateTimePickerStajBitisTarihi
            // 
            this.dateTimePickerStajBitisTarihi.Location = new System.Drawing.Point(199, 67);
            this.dateTimePickerStajBitisTarihi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerStajBitisTarihi.Name = "dateTimePickerStajBitisTarihi";
            this.dateTimePickerStajBitisTarihi.Size = new System.Drawing.Size(151, 20);
            this.dateTimePickerStajBitisTarihi.TabIndex = 13;
            // 
            // dateTimePickerBaslangicTarihi
            // 
            this.dateTimePickerBaslangicTarihi.Location = new System.Drawing.Point(199, 31);
            this.dateTimePickerBaslangicTarihi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerBaslangicTarihi.Name = "dateTimePickerBaslangicTarihi";
            this.dateTimePickerBaslangicTarihi.Size = new System.Drawing.Size(151, 20);
            this.dateTimePickerBaslangicTarihi.TabIndex = 12;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox3.Controls.Add(this.comboBoxStajKodu);
            this.groupBox3.Controls.Add(this.textBoxStajYeri);
            this.groupBox3.Controls.Add(this.textBoxEPosta);
            this.groupBox3.Controls.Add(this.textBoxCepTelNo);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Location = new System.Drawing.Point(14, 440);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(484, 193);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            // 
            // comboBoxStajKodu
            // 
            this.comboBoxStajKodu.FormattingEnabled = true;
            this.comboBoxStajKodu.Items.AddRange(new object[] {
            "end300",
            "end400"});
            this.comboBoxStajKodu.Location = new System.Drawing.Point(199, 107);
            this.comboBoxStajKodu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxStajKodu.Name = "comboBoxStajKodu";
            this.comboBoxStajKodu.Size = new System.Drawing.Size(174, 21);
            this.comboBoxStajKodu.TabIndex = 11;
            // 
            // textBoxStajYeri
            // 
            this.textBoxStajYeri.Location = new System.Drawing.Point(199, 145);
            this.textBoxStajYeri.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxStajYeri.Name = "textBoxStajYeri";
            this.textBoxStajYeri.Size = new System.Drawing.Size(174, 20);
            this.textBoxStajYeri.TabIndex = 14;
            // 
            // textBoxEPosta
            // 
            this.textBoxEPosta.Location = new System.Drawing.Point(199, 76);
            this.textBoxEPosta.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxEPosta.Name = "textBoxEPosta";
            this.textBoxEPosta.Size = new System.Drawing.Size(174, 20);
            this.textBoxEPosta.TabIndex = 12;
            // 
            // textBoxCepTelNo
            // 
            this.textBoxCepTelNo.Location = new System.Drawing.Point(199, 38);
            this.textBoxCepTelNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxCepTelNo.Name = "textBoxCepTelNo";
            this.textBoxCepTelNo.Size = new System.Drawing.Size(174, 20);
            this.textBoxCepTelNo.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox2.Controls.Add(this.comboBoxSinifi);
            this.groupBox2.Controls.Add(this.textBoxOgrNo);
            this.groupBox2.Controls.Add(this.textBoxSoyad);
            this.groupBox2.Controls.Add(this.textBoxAd);
            this.groupBox2.Controls.Add(this.textBoxTcNo);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(14, 176);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(484, 198);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            // 
            // comboBoxSinifi
            // 
            this.comboBoxSinifi.FormattingEnabled = true;
            this.comboBoxSinifi.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.comboBoxSinifi.Location = new System.Drawing.Point(199, 158);
            this.comboBoxSinifi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxSinifi.Name = "comboBoxSinifi";
            this.comboBoxSinifi.Size = new System.Drawing.Size(174, 21);
            this.comboBoxSinifi.TabIndex = 10;
            // 
            // textBoxOgrNo
            // 
            this.textBoxOgrNo.Location = new System.Drawing.Point(199, 128);
            this.textBoxOgrNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxOgrNo.Name = "textBoxOgrNo";
            this.textBoxOgrNo.Size = new System.Drawing.Size(174, 20);
            this.textBoxOgrNo.TabIndex = 9;
            // 
            // textBoxSoyad
            // 
            this.textBoxSoyad.Location = new System.Drawing.Point(199, 92);
            this.textBoxSoyad.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxSoyad.Name = "textBoxSoyad";
            this.textBoxSoyad.Size = new System.Drawing.Size(174, 20);
            this.textBoxSoyad.TabIndex = 8;
            // 
            // textBoxAd
            // 
            this.textBoxAd.Location = new System.Drawing.Point(199, 53);
            this.textBoxAd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAd.Name = "textBoxAd";
            this.textBoxAd.Size = new System.Drawing.Size(174, 20);
            this.textBoxAd.TabIndex = 7;
            // 
            // textBoxTcNo
            // 
            this.textBoxTcNo.Location = new System.Drawing.Point(199, 17);
            this.textBoxTcNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxTcNo.Name = "textBoxTcNo";
            this.textBoxTcNo.Size = new System.Drawing.Size(174, 20);
            this.textBoxTcNo.TabIndex = 6;
            // 
            // buttonCikis
            // 
            this.buttonCikis.BackColor = System.Drawing.Color.OrangeRed;
            this.buttonCikis.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonCikis.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonCikis.Location = new System.Drawing.Point(1085, 790);
            this.buttonCikis.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonCikis.Name = "buttonCikis";
            this.buttonCikis.Size = new System.Drawing.Size(145, 62);
            this.buttonCikis.TabIndex = 22;
            this.buttonCikis.Text = "Çıkış";
            this.buttonCikis.UseVisualStyleBackColor = false;
            this.buttonCikis.Click += new System.EventHandler(this.buttonCikis_Click);
            // 
            // buttonTemizle
            // 
            this.buttonTemizle.BackColor = System.Drawing.Color.Yellow;
            this.buttonTemizle.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonTemizle.Location = new System.Drawing.Point(1234, 789);
            this.buttonTemizle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonTemizle.Name = "buttonTemizle";
            this.buttonTemizle.Size = new System.Drawing.Size(141, 61);
            this.buttonTemizle.TabIndex = 23;
            this.buttonTemizle.Text = "Temizle";
            this.buttonTemizle.UseVisualStyleBackColor = false;
            this.buttonTemizle.Click += new System.EventHandler(this.buttonTemizle_Click);
            // 
            // buttonKaydetGuncelle
            // 
            this.buttonKaydetGuncelle.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonKaydetGuncelle.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonKaydetGuncelle.Location = new System.Drawing.Point(1379, 788);
            this.buttonKaydetGuncelle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonKaydetGuncelle.Name = "buttonKaydetGuncelle";
            this.buttonKaydetGuncelle.Size = new System.Drawing.Size(134, 62);
            this.buttonKaydetGuncelle.TabIndex = 24;
            this.buttonKaydetGuncelle.Text = "Kaydet";
            this.buttonKaydetGuncelle.UseVisualStyleBackColor = false;
            this.buttonKaydetGuncelle.Click += new System.EventHandler(this.buttonKaydetGuncelle_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1085, 17);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(428, 767);
            this.dataGridView1.TabIndex = 25;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // comboBoxogretmen
            // 
            this.comboBoxogretmen.FormattingEnabled = true;
            this.comboBoxogretmen.Items.AddRange(new object[] {
            "tugba",
            "emre"});
            this.comboBoxogretmen.Location = new System.Drawing.Point(810, 794);
            this.comboBoxogretmen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxogretmen.Name = "comboBoxogretmen";
            this.comboBoxogretmen.Size = new System.Drawing.Size(148, 21);
            this.comboBoxogretmen.TabIndex = 26;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.checkBoxEvrakteslimEdildimi);
            this.groupBox8.Controls.Add(this.textboxKayitNo);
            this.groupBox8.Controls.Add(this.comboBoxbasaiKontrol);
            this.groupBox8.Location = new System.Drawing.Point(14, 38);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1029, 57);
            this.groupBox8.TabIndex = 29;
            this.groupBox8.TabStop = false;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.Maroon;
            this.label23.Location = new System.Drawing.Point(646, 794);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(160, 20);
            this.label23.TabIndex = 27;
            this.label23.Text = "Öğretmeni : ";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Bitirme_Projesi.Properties.Resources.backform2_new;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1524, 884);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonKaydetGuncelle);
            this.Controls.Add(this.buttonTemizle);
            this.Controls.Add(this.buttonCikis);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Endüstri Mühendisliği Staj Veritabanı Kayıt/İzleme Formu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox textboxKayitNo;
        private System.Windows.Forms.TextBox textBoxStajYeri;
        private System.Windows.Forms.TextBox textBoxEPosta;
        private System.Windows.Forms.TextBox textBoxCepTelNo;
        private System.Windows.Forms.TextBox textBoxOgrNo;
        private System.Windows.Forms.TextBox textBoxSoyad;
        private System.Windows.Forms.TextBox textBoxAd;
        private System.Windows.Forms.TextBox textBoxTcNo;
        private System.Windows.Forms.ComboBox comboBoxbasaiKontrol;
        private System.Windows.Forms.DateTimePicker dateTimePickerStajBitisTarihi;
        private System.Windows.Forms.DateTimePicker dateTimePickerBaslangicTarihi;
        private System.Windows.Forms.ComboBox comboBoxStajKodu;
        private System.Windows.Forms.ComboBox comboBoxSinifi;
        private System.Windows.Forms.CheckBox checkBoxEvrakteslimEdildimi;
        private System.Windows.Forms.RichTextBox richTextBoxAciklama;
        private System.Windows.Forms.CheckBox checkBoxStajRaporu;
        private System.Windows.Forms.CheckBox checkBoxStajDegerlendirmeFormu;
        private System.Windows.Forms.CheckBox checkBoxKimlikFotokopisiVerildimi;
        private System.Windows.Forms.CheckBox checkBoxMustehaklikBelgesiVerildimi;
        private System.Windows.Forms.CheckBox checkBoxKabulYazısıGetirildimi;
        private System.Windows.Forms.CheckBox checkBoxBasvuruDilekcesiVerildimi;
        private System.Windows.Forms.TextBox textBoxEnd300400Kodu;
        private System.Windows.Forms.TextBox textBoxZorunluStajYazısıKodu;
        private System.Windows.Forms.Button buttonCikis;
        private System.Windows.Forms.Button buttonTemizle;
        private System.Windows.Forms.Button buttonKaydetGuncelle;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBoxogretmen;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label23;
    }
}