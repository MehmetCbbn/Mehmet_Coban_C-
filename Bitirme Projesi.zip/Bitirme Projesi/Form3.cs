﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bitirme_Projesi
{
    public partial class Form3 : Form
    {
        private MySqlConnection connection;
        private String ad;
        private long ogrenci_no;

        public Form3(String ad)
        {
            this.ad = ad; 
            InitializeComponent();
            InitializeDatabaseConnection();
        }

        private void InitializeDatabaseConnection()
        {
            connection = new MySqlConnection("Server=localhost;Database=stajproje;user=root;Pwd=;Convert Zero Datetime=True");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int toplamPuan = comboBoxislemdegerlendirmesi.SelectedIndex +
                comboBoxsekilyazibicimdegerlendirmesi.SelectedIndex +
                     comboBoxsoru1.SelectedIndex +
                     comboBoxsoru2.SelectedIndex +
                     comboBoxSoru3.SelectedIndex +
                     comboBoxSoru4.SelectedIndex +
                     comboBoxsoru5.SelectedIndex +
                     comboBoxSoru6.SelectedIndex +
                     comboBoxSoru7.SelectedIndex +
                     comboBoxSoru8.SelectedIndex +
                     comboBoxSoru9.SelectedIndex +
                     comboBoxSoru10.SelectedIndex +
                     comboBoxSoru11.SelectedIndex +
                     comboBoxSoru12.SelectedIndex +
                     comboBoxSoru13.SelectedIndex +
                     comboBoxSoru14.SelectedIndex +
                     comboBoxSoru15.SelectedIndex +
                     comboBoxSoru16.SelectedIndex +
                     comboBoxSoru17.SelectedIndex +
                     comboBoxSoru18.SelectedIndex +
                     comboBoxSoru19.SelectedIndex;

            try
            {
                connection.Open();

                // Öğrenci numarasıyla veritabanında bir kayıt olup olmadığını kontrol et
                string kontrolSorgusu = "SELECT COUNT(*) FROM puanlar WHERE ogr_no = @ogr_no";
                using (MySqlCommand kontrolKomutu = new MySqlCommand(kontrolSorgusu, connection))
                {
                    kontrolKomutu.Parameters.AddWithValue("@ogr_no", ogrenci_no);
                    int kayitSayisi = Convert.ToInt32(kontrolKomutu.ExecuteScalar());

                    if (kayitSayisi > 0)
                    {
                        // Eğer öğrenci numarası zaten varsa, güncelleme yap
                        string guncelleSorgusu = "UPDATE puanlar SET ogr_puan = @ogr_puan WHERE ogr_no = @ogr_no";
                        using (MySqlCommand guncelleKomutu = new MySqlCommand(guncelleSorgusu, connection))
                        {
                            guncelleKomutu.Parameters.AddWithValue("@ogr_no", ogrenci_no);
                            guncelleKomutu.Parameters.AddWithValue("@ogr_puan", toplamPuan);

                            guncelleKomutu.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // Eğer öğrenci numarası yoksa, yeni bir kayıt ekle
                        string ekleSorgusu = "INSERT INTO puanlar (ogr_no, ogr_puan) VALUES (@ogr_no, @ogr_puan)";
                        using (MySqlCommand ekleKomutu = new MySqlCommand(ekleSorgusu, connection))
                        {
                            ekleKomutu.Parameters.AddWithValue("@ogr_no", ogrenci_no);
                            ekleKomutu.Parameters.AddWithValue("@ogr_puan", toplamPuan);

                            ekleKomutu.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Kayıt Eklendi");
                new Form3(ad).Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt ekleme sırasında bir hata oluştu: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            LoadData();
            comboBoxislemdegerlendirmesi.SelectedIndex = 0;
            comboBoxsekilyazibicimdegerlendirmesi.SelectedIndex = 0;
            comboBoxsoru1.SelectedIndex = 0;
            comboBoxsoru2.SelectedIndex = 0;
            comboBoxSoru3.SelectedIndex = 0;
            comboBoxSoru4.SelectedIndex = 0;
            comboBoxsoru5.SelectedIndex = 0;
            comboBoxSoru6.SelectedIndex = 0;
            comboBoxSoru7.SelectedIndex = 0;
            comboBoxSoru8.SelectedIndex = 0;
            comboBoxSoru9.SelectedIndex = 0;
            comboBoxSoru10.SelectedIndex = 0;
            comboBoxSoru11.SelectedIndex = 0;
            comboBoxSoru12.SelectedIndex = 0;
            comboBoxSoru13.SelectedIndex = 0;
            comboBoxSoru14.SelectedIndex = 0;
            comboBoxSoru15.SelectedIndex = 0;
            comboBoxSoru16.SelectedIndex = 0;
            comboBoxSoru17.SelectedIndex = 0;
            comboBoxSoru18.SelectedIndex = 0;
            comboBoxSoru19.SelectedIndex = 0;
        }

        private void LoadData()
        {
            try
            {
                connection.Open();
                string query = @"
            SELECT o.ogr_ad, o.ogr_soyad, o.ogr_no
            , o.ogr_staj_kod, o.ogr_staj_yer,o.ogr_cep_tel_no, o.ogr_eposta
            , o.ogr_staj_baslangic, o.ogr_staj_bitis ,o.ogr_stajbasarikontrol, p.ogr_puan 
            FROM ogrenciler AS o
            LEFT JOIN puanlar AS p ON o.ogr_no = p.ogr_no
            WHERE o.ogr_ogretmen = @ad";

                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@ad", ad);

                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridViewOgrenciler.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanı bağlantısı başarısız oldu: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void dataGridViewOgrenciler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewOgrenciler.Rows[e.RowIndex];
                if (row.Cells["ogr_no"].Value != DBNull.Value)
                {
                    ogrenci_no = Convert.ToInt32(row.Cells["ogr_no"].Value);
                }else{
                    ogrenci_no = 0; 
                }

                string ogr_ad = row.Cells["ogr_ad"].Value != DBNull.Value ? row.Cells["ogr_ad"].Value.ToString() : string.Empty;

                string ogr_soyad = row.Cells["ogr_soyad"].Value != DBNull.Value ? row.Cells["ogr_soyad"].Value.ToString() : string.Empty;

                string ogr_staj_kod = row.Cells["ogr_staj_kod"].Value != DBNull.Value ? row.Cells["ogr_staj_kod"].Value.ToString() : string.Empty;
                string staj_baslangic = row.Cells["ogr_staj_baslangic"].Value != DBNull.Value ? row.Cells["ogr_staj_baslangic"].Value.ToString() : string.Empty;
                string staj_bitis = row.Cells["ogr_staj_bitis"].Value != DBNull.Value ? row.Cells["ogr_staj_bitis"].Value.ToString() : string.Empty;
                string staj_yer = row.Cells["ogr_staj_yer"].Value != DBNull.Value ? row.Cells["ogr_staj_yer"].Value.ToString() : string.Empty;

                int ogr_sinif = row.Cells["ogr_stajbasarikontrol"].Value != DBNull.Value ? Convert.ToInt32(row.Cells["ogr_stajbasarikontrol"].Value) : 0; 

                int ogr_puan = row.Cells["ogr_puan"].Value != DBNull.Value ? Convert.ToInt32(row.Cells["ogr_puan"].Value) : 0;
                labeltoplampuan.Visible = true;
                labeltoplampuan.Text = "Staj Puanı : " + ogr_puan;


                formtextad.Text = ogr_ad + " "+ ogr_soyad;
                formtextsinif.Text = ogr_sinif + ".Sınıf";
                formtextno.Text = ogrenci_no.ToString();
                formtextstajbaslangic.Text = "Staj Başlangıçı : "+staj_baslangic;
                formtextstajbitis.Text = "Staj Bitişi : "+staj_bitis;
                formtextstajyer.Text = "Staj Yeri : "+staj_yer;
                comboBoxbasarıkontrol.SelectedIndex = ogr_sinif;
                pictureBoxogrenci.Visible = true;
            }
        }

        private void buttonsil_Click(object sender, EventArgs e)
        {

            if (ogrenci_no != 0)
            {
                DialogResult result = MessageBox.Show("Seçili öğrenciyi silmek istediğinize emin misiniz?", "Öğrenci Silme", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        connection.Open();

                        string puanSilSorgusu = "DELETE FROM puanlar WHERE ogr_no = @ogr_no";
                        using (MySqlCommand puanSilKomutu = new MySqlCommand(puanSilSorgusu, connection))
                        {
                            puanSilKomutu.Parameters.AddWithValue("@ogr_no", ogrenci_no);
                            puanSilKomutu.ExecuteNonQuery();
                        }

                        string ogrenciSilSorgusu = "DELETE FROM ogrenciler WHERE ogr_no = @ogr_no";
                        using (MySqlCommand ogrenciSilKomutu = new MySqlCommand(ogrenciSilSorgusu, connection))
                        {
                            ogrenciSilKomutu.Parameters.AddWithValue("@ogr_no", ogrenci_no);
                            ogrenciSilKomutu.ExecuteNonQuery();
                        }

                      
                       
                        MessageBox.Show("Öğrenci başarıyla silindi.");
                        new Form3(ad).Show();
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Öğrenci silinirken bir hata oluştu: " + ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Lütfen bir öğrenci seçin.");
            }
        }

    }
}
