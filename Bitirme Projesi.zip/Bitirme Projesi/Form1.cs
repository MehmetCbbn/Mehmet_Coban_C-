﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace Bitirme_Projesi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            adSoyadGiris.SelectedIndex = 0;
            CenterGroupBoxHorizontally(groupBox1);

            MySqlConnection connection = new MySqlConnection("Server=localhost;Database=stajproje;Uid=root;");

            try
            {
                connection.Open();


                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanı bağlantısı başarısız oldu: " + ex.Message);
            }

            int radius = 20; 
            GraphicsPath path = new GraphicsPath();

            path.AddArc(0, 0, radius * 2, radius * 2, 180, 90);
            path.AddArc(this.Width - radius * 2, 0, radius * 2, radius * 2, 270, 90);
            path.AddArc(this.Width - radius * 2, this.Height - radius * 2, radius * 2, radius * 2, 0, 90);
            path.AddArc(0, this.Height - radius * 2, radius * 2, radius * 2, 90, 90);
            path.CloseFigure();

            this.Region = new Region(path); 
        }

        private void buttonGiris_Click(object sender, EventArgs e)
        {



            string query = "SELECT kul_tur FROM kullanicilar WHERE kul_ad = @kullaniciAdi AND kul_sif = @sifre";


            using (MySqlConnection connection = new MySqlConnection("Server=localhost;Database=stajproje;Uid=root;"))
            {

                connection.Open();


                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@kullaniciAdi", adSoyadGiris.Text);
                command.Parameters.AddWithValue("@sifre", sifreGiris.Text);

                object result = command.ExecuteScalar();


                if (result != null && result != DBNull.Value)
                {
                    string kullaniciTuru = result.ToString();


                    if (kullaniciTuru == "ogretmen")
                    {
                        Form3 form3 = new Form3(adSoyadGiris.Text);
                        form3.Show();
                    }
                    else if (kullaniciTuru == "sekreter")
                    {
                        Form2 form2 = new Form2();
                        form2.Show();
                        
                    }
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre hatalı.");
                }
            }
        }

        private void buttoncikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CenterGroupBoxHorizontally(GroupBox groupBox)
        {
    
            int groupBoxWidth = 450; 
            groupBox.Width = groupBoxWidth;

            int formWidth = this.ClientSize.Width;

            groupBox.Left = (formWidth - groupBoxWidth) / 2;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            string url = "https://docs.google.com/document/d/1aK_4Eea6PgfCGPWr51GSr6WVJ-HKv49Z/edit?usp=drive_link&ouid=108878448046039099651&rtpof=true&sd=true";

            Process.Start(url);
        }
    }
}
