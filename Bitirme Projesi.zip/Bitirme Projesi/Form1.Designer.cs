﻿namespace Bitirme_Projesi
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.buttoncikis = new System.Windows.Forms.Button();
            this.buttonGiris = new System.Windows.Forms.Button();
            this.adSoyadGiris = new System.Windows.Forms.ComboBox();
            this.sifreGiris = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.BackColor = System.Drawing.Color.Maroon;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.buttoncikis);
            this.groupBox1.Controls.Add(this.buttonGiris);
            this.groupBox1.Controls.Add(this.adSoyadGiris);
            this.groupBox1.Controls.Add(this.sifreGiris);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(361, 187);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(593, 642);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(6, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(581, 212);
            this.label4.TabIndex = 7;
            this.label4.Text = "Başkent Üniversitesi Staj Değerlendirme Sistemi";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttoncikis
            // 
            this.buttoncikis.BackColor = System.Drawing.Color.OrangeRed;
            this.buttoncikis.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttoncikis.ForeColor = System.Drawing.Color.White;
            this.buttoncikis.Location = new System.Drawing.Point(129, 485);
            this.buttoncikis.Margin = new System.Windows.Forms.Padding(0);
            this.buttoncikis.Name = "buttoncikis";
            this.buttoncikis.Size = new System.Drawing.Size(142, 68);
            this.buttoncikis.TabIndex = 6;
            this.buttoncikis.Text = "Çıkış";
            this.buttoncikis.UseVisualStyleBackColor = false;
            this.buttoncikis.Click += new System.EventHandler(this.buttoncikis_Click);
            // 
            // buttonGiris
            // 
            this.buttonGiris.BackColor = System.Drawing.Color.Lime;
            this.buttonGiris.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGiris.Location = new System.Drawing.Point(313, 485);
            this.buttonGiris.Margin = new System.Windows.Forms.Padding(0);
            this.buttonGiris.Name = "buttonGiris";
            this.buttonGiris.Size = new System.Drawing.Size(142, 68);
            this.buttonGiris.TabIndex = 5;
            this.buttonGiris.Text = "Giriş";
            this.buttonGiris.UseVisualStyleBackColor = false;
            this.buttonGiris.Click += new System.EventHandler(this.buttonGiris_Click);
            // 
            // adSoyadGiris
            // 
            this.adSoyadGiris.DropDownHeight = 210;
            this.adSoyadGiris.FormattingEnabled = true;
            this.adSoyadGiris.IntegralHeight = false;
            this.adSoyadGiris.Items.AddRange(new object[] {
            "Muhammed",
            "Sekreter",
            "tugba",
            "emre"});
            this.adSoyadGiris.Location = new System.Drawing.Point(192, 273);
            this.adSoyadGiris.Name = "adSoyadGiris";
            this.adSoyadGiris.Size = new System.Drawing.Size(210, 24);
            this.adSoyadGiris.TabIndex = 4;
            // 
            // sifreGiris
            // 
            this.sifreGiris.Location = new System.Drawing.Point(192, 395);
            this.sifreGiris.Name = "sifreGiris";
            this.sifreGiris.Size = new System.Drawing.Size(210, 22);
            this.sifreGiris.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(6, 346);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(581, 46);
            this.label2.TabIndex = 2;
            this.label2.Text = "Şifre";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(6, 221);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(581, 49);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ad Soyad";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.LavenderBlush;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(223, 437);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 36);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nasıl Kullanılır ? ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orchid;
            this.BackgroundImage = global::Bitirme_Projesi.Properties.Resources.back1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1360, 745);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Endüstri Mühendisliği Staj Değerlendirme Giriş Formu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonGiris;
        private System.Windows.Forms.ComboBox adSoyadGiris;
        private System.Windows.Forms.TextBox sifreGiris;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttoncikis;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}

