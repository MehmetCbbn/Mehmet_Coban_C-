﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace Bitirme_Projesi
{
    public partial class Form2 : Form
    {
        private MySqlConnection connection;

        public Form2()
        {
            InitializeComponent();
            connection = new MySqlConnection("Server = localhost; Database = stajproje; user = root; Pwd = ;Convert Zero Datetime = True");


            try
            {
                connection.Open();
                LoadData();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanı bağlantısı başarısız oldu: " + ex.Message);
            }
        }

        private void LoadData()
        {
            string query = "SELECT * FROM ogrenciler";

            MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            dataGridView1.DataSource = dataTable;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];


                int ogr_kayit_no = Convert.ToInt32(row.Cells["ogr_kayit_no"].Value);
                string ogr_ad = row.Cells["ogr_ad"].Value.ToString();
                string ogr_soyad = row.Cells["ogr_soyad"].Value.ToString();
                int ogr_no = Convert.ToInt32(row.Cells["ogr_no"].Value);
                int ogr_sinif = Convert.ToInt32(row.Cells["ogr_sinif"].Value);
                string ogr_staj_kod = row.Cells["ogr_staj_kod"].Value.ToString();
                string ogr_staj_yer = row.Cells["ogr_staj_yer"].Value.ToString();
                string ogr_ogretmen = row.Cells["ogr_ogretmen"].Value.ToString();
                long ogr_tc_no = Convert.ToInt64(row.Cells["ogr_tc_no"].Value.ToString());
                long ogr_cep_tel_no = Convert.ToInt64(row.Cells["ogr_cep_tel_no"].Value.ToString());
                string ogr_eposta = row.Cells["ogr_eposta"].Value.ToString();
                DateTime ogr_staj_baslangic = Convert.ToDateTime(row.Cells["ogr_staj_baslangic"].Value);
                DateTime ogr_staj_bitis = Convert.ToDateTime(row.Cells["ogr_staj_bitis"].Value);
                int ogr_evrakpersonelteslim = Convert.ToInt32(row.Cells["ogr_evrakpersonelteslim"].Value);
                int ogr_mustehaklikbelgesi = Convert.ToInt32(row.Cells["ogr_mustehaklikbelgesi"].Value);
                int ogr_basvurudilekcesi = Convert.ToInt32(row.Cells["ogr_basvurudilekcesi"].Value);
                int ogr_kimlikfotokopisi = Convert.ToInt32(row.Cells["ogr_kimlikfotokopisi"].Value);
                int ogr_stajdegerlendirme = Convert.ToInt32(row.Cells["ogr_stajdegerlendirme"].Value);
                int ogr_stajraporu = Convert.ToInt32(row.Cells["ogr_stajraporu"].Value);
                int ogr_stajbasarikontrol = Convert.ToInt32(row.Cells["ogr_stajbasarikontrol"].Value);

          
                textboxKayitNo.Text = ogr_kayit_no.ToString();
                textBoxAd.Text = ogr_ad;
                textBoxSoyad.Text = ogr_soyad;
                textBoxOgrNo.Text = ogr_no.ToString();
                comboBoxSinifi.SelectedIndex = (ogr_sinif - 1);
                textBoxZorunluStajYazısıKodu.Text = ogr_staj_kod;
                textBoxStajYeri.Text = ogr_staj_yer;
                comboBoxogretmen.Text = ogr_ogretmen;
                textBoxTcNo.Text = ogr_tc_no.ToString();
                comboBoxStajKodu.Text = ogr_staj_kod;
                textBoxCepTelNo.Text = ogr_cep_tel_no.ToString();
                textBoxEPosta.Text = ogr_eposta;
                dateTimePickerBaslangicTarihi.Value = ogr_staj_baslangic;
                dateTimePickerStajBitisTarihi.Value = ogr_staj_bitis;
                checkBoxEvrakteslimEdildimi.Checked = ogr_evrakpersonelteslim == 1; 
                checkBoxMustehaklikBelgesiVerildimi.Checked = ogr_mustehaklikbelgesi == 1;
                checkBoxKabulYazısıGetirildimi.Checked = ogr_basvurudilekcesi == 1;
                checkBoxKimlikFotokopisiVerildimi.Checked = ogr_kimlikfotokopisi == 1;
                checkBoxStajDegerlendirmeFormu.Checked = ogr_stajdegerlendirme == 1;
                checkBoxStajRaporu.Checked = ogr_stajraporu == 1;
                comboBoxbasaiKontrol.SelectedIndex = ogr_stajbasarikontrol;

            }
        }

        private void buttonKaydetGuncelle_Click(object sender, EventArgs e)
        {
            int ogr_kayit_no;
            if (!(string.IsNullOrWhiteSpace(textboxKayitNo.Text)))
            {
                ogr_kayit_no = Convert.ToInt32(textboxKayitNo.Text);
            }
            else
            {
                ogr_kayit_no = 0;
            }
            
            string ogr_ad = textBoxAd.Text;
            string ogr_soyad = textBoxSoyad.Text;
            int ogr_no = Convert.ToInt32(textBoxOgrNo.Text);
            int ogr_sinif = comboBoxSinifi.SelectedIndex + 1; // ComboBox 0'dan başlar, ancak veritabanında 1'den başlar
            string ogr_staj_kod = textBoxZorunluStajYazısıKodu.Text;
            string ogr_staj_yer = textBoxStajYeri.Text;
            string ogr_ogretmen = comboBoxogretmen.Text;
            long ogr_tc_no = Convert.ToInt64(textBoxTcNo.Text);
            long ogr_cep_tel_no = Convert.ToInt64(textBoxCepTelNo.Text);
            string ogr_eposta = textBoxEPosta.Text;
            DateTime ogr_staj_baslangic = dateTimePickerBaslangicTarihi.Value;
            DateTime ogr_staj_bitis = dateTimePickerStajBitisTarihi.Value;
            int ogr_evrakpersonelteslim = checkBoxEvrakteslimEdildimi.Checked ? 1 : 0; // CheckBox'tan alınan değeri 1 veya 0 olarak dönüştürme
            int ogr_mustehaklikbelgesi = checkBoxMustehaklikBelgesiVerildimi.Checked ? 1 : 0;
            int ogr_basvurudilekcesi = checkBoxKabulYazısıGetirildimi.Checked ? 1 : 0;
            int ogr_kimlikfotokopisi = checkBoxKimlikFotokopisiVerildimi.Checked ? 1 : 0;
            int ogr_stajdegerlendirme = checkBoxStajDegerlendirmeFormu.Checked ? 1 : 0;
            int ogr_stajraporu = checkBoxStajRaporu.Checked ? 1 : 0;
            int ogr_stajbasarikontrol = comboBoxbasaiKontrol.SelectedIndex;

         
            using (MySqlConnection connection = new MySqlConnection("Server=localhost;Database=stajproje;user=root;Pwd=;Convert Zero Datetime=True"))
            {
                connection.Open();

            
                string kontrolSorgusu = "SELECT COUNT(*) FROM ogrenciler WHERE ogr_kayit_no = @ogr_kayit_no";
                using (MySqlCommand kontrolKomutu = new MySqlCommand(kontrolSorgusu, connection))
                {
                    if (!(ogr_kayit_no == 0))
                    {
                        kontrolKomutu.Parameters.AddWithValue("@ogr_kayit_no", ogr_kayit_no);
                        int kayitSayisi = Convert.ToInt32(kontrolKomutu.ExecuteScalar());

                        if (kayitSayisi > 0)
                        {

                            string guncelleSorgusu = "UPDATE ogrenciler SET ogr_ad = @ogr_ad, ogr_soyad = @ogr_soyad, ogr_no = @ogr_no, ogr_sinif = @ogr_sinif, ogr_staj_kod = @ogr_staj_kod, ogr_staj_yer = @ogr_staj_yer, ogr_ogretmen = @ogr_ogretmen, ogr_tc_no = @ogr_tc_no, ogr_cep_tel_no = @ogr_cep_tel_no, ogr_eposta = @ogr_eposta, ogr_staj_baslangic = @ogr_staj_baslangic, ogr_staj_bitis = @ogr_staj_bitis, ogr_evrakpersonelteslim = @ogr_evrakpersonelteslim, ogr_mustehaklikbelgesi = @ogr_mustehaklikbelgesi, ogr_basvurudilekcesi = @ogr_basvurudilekcesi, ogr_kimlikfotokopisi = @ogr_kimlikfotokopisi, ogr_stajdegerlendirme = @ogr_stajdegerlendirme, ogr_stajraporu = @ogr_stajraporu, ogr_stajbasarikontrol = @ogr_stajbasarikontrol WHERE ogr_kayit_no = @ogr_kayit_no";
                            using (MySqlCommand guncelleKomutu = new MySqlCommand(guncelleSorgusu, connection))
                            {
                                guncelleKomutu.Parameters.AddWithValue("@ogr_ad", ogr_ad);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_soyad", ogr_soyad);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_no", ogr_no);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_sinif", ogr_sinif);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_staj_kod", ogr_staj_kod);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_staj_yer", ogr_staj_yer);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_ogretmen", ogr_ogretmen);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_tc_no", ogr_tc_no);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_cep_tel_no", ogr_cep_tel_no);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_eposta", ogr_eposta);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_staj_baslangic", ogr_staj_baslangic);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_staj_bitis", ogr_staj_bitis);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_evrakpersonelteslim", ogr_evrakpersonelteslim);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_mustehaklikbelgesi", ogr_mustehaklikbelgesi);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_basvurudilekcesi", ogr_basvurudilekcesi);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_kimlikfotokopisi", ogr_kimlikfotokopisi);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_stajdegerlendirme", ogr_stajdegerlendirme);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_stajraporu", ogr_stajraporu);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_stajbasarikontrol", ogr_stajbasarikontrol);
                                guncelleKomutu.Parameters.AddWithValue("@ogr_kayit_no", ogr_kayit_no);

                                guncelleKomutu.ExecuteNonQuery();
                                MessageBox.Show("Kayıt Güncellendi");
                                new Form2().Show();
                                this.Close();
                                
                            }
                        }
                        else
                        {

                            string ekleSorgusu = "INSERT INTO ogrenciler (ogr_ad, ogr_soyad, ogr_no, ogr_sinif, ogr_staj_kod, ogr_staj_yer, ogr_ogretmen, ogr_tc_no, ogr_cep_tel_no, ogr_eposta, ogr_staj_baslangic, ogr_staj_bitis, ogr_evrakpersonelteslim, ogr_mustehaklikbelgesi, ogr_basvurudilekcesi, ogr_kimlikfotokopisi, ogr_stajdegerlendirme, ogr_stajraporu, ogr_stajbasarikontrol) VALUES (@ogr_ad, @ogr_soyad, @ogr_no, @ogr_sinif, @ogr_staj_kod, @ogr_staj_yer, @ogr_ogretmen, @ogr_tc_no, @ogr_cep_tel_no, @ogr_eposta, @ogr_staj_baslangic, @ogr_staj_bitis, @ogr_evrakpersonelteslim, @ogr_mustehaklikbelgesi, @ogr_basvurudilekcesi, @ogr_kimlikfotokopisi, @ogr_stajdegerlendirme, @ogr_stajraporu, @ogr_stajbasarikontrol)";
                            using (MySqlCommand ekleKomutu = new MySqlCommand(ekleSorgusu, connection))
                            {
                                ekleKomutu.Parameters.AddWithValue("@ogr_ad", ogr_ad);
                                ekleKomutu.Parameters.AddWithValue("@ogr_soyad", ogr_soyad);
                                ekleKomutu.Parameters.AddWithValue("@ogr_no", ogr_no);
                                ekleKomutu.Parameters.AddWithValue("@ogr_sinif", ogr_sinif);
                                ekleKomutu.Parameters.AddWithValue("@ogr_staj_kod", ogr_staj_kod);
                                ekleKomutu.Parameters.AddWithValue("@ogr_staj_yer", ogr_staj_yer);
                                ekleKomutu.Parameters.AddWithValue("@ogr_ogretmen", ogr_ogretmen);
                                ekleKomutu.Parameters.AddWithValue("@ogr_tc_no", ogr_tc_no);
                                ekleKomutu.Parameters.AddWithValue("@ogr_cep_tel_no", ogr_cep_tel_no);
                                ekleKomutu.Parameters.AddWithValue("@ogr_eposta", ogr_eposta);
                                ekleKomutu.Parameters.AddWithValue("@ogr_staj_baslangic", ogr_staj_baslangic);
                                ekleKomutu.Parameters.AddWithValue("@ogr_staj_bitis", ogr_staj_bitis);
                                ekleKomutu.Parameters.AddWithValue("@ogr_evrakpersonelteslim", ogr_evrakpersonelteslim);
                                ekleKomutu.Parameters.AddWithValue("@ogr_mustehaklikbelgesi", ogr_mustehaklikbelgesi);
                                ekleKomutu.Parameters.AddWithValue("@ogr_basvurudilekcesi", ogr_basvurudilekcesi);
                                ekleKomutu.Parameters.AddWithValue("@ogr_kimlikfotokopisi", ogr_kimlikfotokopisi);
                                ekleKomutu.Parameters.AddWithValue("@ogr_stajdegerlendirme", ogr_stajdegerlendirme);
                                ekleKomutu.Parameters.AddWithValue("@ogr_stajraporu", ogr_stajraporu);
                                ekleKomutu.Parameters.AddWithValue("@ogr_stajbasarikontrol", ogr_stajbasarikontrol);

                                ekleKomutu.ExecuteNonQuery();
                                MessageBox.Show("Kayıt Eklendi");
                                new Form2().Show();
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        string ekleSorgusu = "INSERT INTO ogrenciler (ogr_ad, ogr_soyad, ogr_no, ogr_sinif, ogr_staj_kod, ogr_staj_yer, ogr_ogretmen, ogr_tc_no, ogr_cep_tel_no, ogr_eposta, ogr_staj_baslangic, ogr_staj_bitis, ogr_evrakpersonelteslim, ogr_mustehaklikbelgesi, ogr_basvurudilekcesi, ogr_kimlikfotokopisi, ogr_stajdegerlendirme, ogr_stajraporu, ogr_stajbasarikontrol) VALUES (@ogr_ad, @ogr_soyad, @ogr_no, @ogr_sinif, @ogr_staj_kod, @ogr_staj_yer, @ogr_ogretmen, @ogr_tc_no, @ogr_cep_tel_no, @ogr_eposta, @ogr_staj_baslangic, @ogr_staj_bitis, @ogr_evrakpersonelteslim, @ogr_mustehaklikbelgesi, @ogr_basvurudilekcesi, @ogr_kimlikfotokopisi, @ogr_stajdegerlendirme, @ogr_stajraporu, @ogr_stajbasarikontrol)";
                        using (MySqlCommand ekleKomutu = new MySqlCommand(ekleSorgusu, connection))
                        {
                            ekleKomutu.Parameters.AddWithValue("@ogr_ad", ogr_ad);
                            ekleKomutu.Parameters.AddWithValue("@ogr_soyad", ogr_soyad);
                            ekleKomutu.Parameters.AddWithValue("@ogr_no", ogr_no);
                            ekleKomutu.Parameters.AddWithValue("@ogr_sinif", ogr_sinif);
                            ekleKomutu.Parameters.AddWithValue("@ogr_staj_kod", ogr_staj_kod);
                            ekleKomutu.Parameters.AddWithValue("@ogr_staj_yer", ogr_staj_yer);
                            ekleKomutu.Parameters.AddWithValue("@ogr_ogretmen", ogr_ogretmen);
                            ekleKomutu.Parameters.AddWithValue("@ogr_tc_no", ogr_tc_no);
                            ekleKomutu.Parameters.AddWithValue("@ogr_cep_tel_no", ogr_cep_tel_no);
                            ekleKomutu.Parameters.AddWithValue("@ogr_eposta", ogr_eposta);
                            ekleKomutu.Parameters.AddWithValue("@ogr_staj_baslangic", ogr_staj_baslangic);
                            ekleKomutu.Parameters.AddWithValue("@ogr_staj_bitis", ogr_staj_bitis);
                            ekleKomutu.Parameters.AddWithValue("@ogr_evrakpersonelteslim", ogr_evrakpersonelteslim);
                            ekleKomutu.Parameters.AddWithValue("@ogr_mustehaklikbelgesi", ogr_mustehaklikbelgesi);
                            ekleKomutu.Parameters.AddWithValue("@ogr_basvurudilekcesi", ogr_basvurudilekcesi);
                            ekleKomutu.Parameters.AddWithValue("@ogr_kimlikfotokopisi", ogr_kimlikfotokopisi);
                            ekleKomutu.Parameters.AddWithValue("@ogr_stajdegerlendirme", ogr_stajdegerlendirme);
                            ekleKomutu.Parameters.AddWithValue("@ogr_stajraporu", ogr_stajraporu);
                            ekleKomutu.Parameters.AddWithValue("@ogr_stajbasarikontrol", ogr_stajbasarikontrol);


                            ekleKomutu.ExecuteNonQuery();
                            MessageBox.Show("Kayıt Eklendi");
                            new Form2().Show();
                            this.Close();
                        }
                    }
                    
                }
            }
        }


        private void buttonTemizle_Click(object sender, EventArgs e)
        {
            textboxKayitNo.Text = "";
            textBoxAd.Text = "";
            textBoxSoyad.Text = "";
            textBoxOgrNo.Text = "";
            comboBoxSinifi.SelectedIndex = -1;
            textBoxZorunluStajYazısıKodu.Text = "";
            textBoxStajYeri.Text = "";
            comboBoxogretmen.SelectedIndex = -1; 
            textBoxTcNo.Text = "";
            comboBoxStajKodu.SelectedIndex = -1;
            textBoxCepTelNo.Text = "";
            textBoxEPosta.Text = "";
            dateTimePickerBaslangicTarihi.Value = DateTime.Now; 
            dateTimePickerStajBitisTarihi.Value = DateTime.Now; // DateTimePicker kontrolüne varsayılan bir tarih atanabilir
            checkBoxEvrakteslimEdildimi.Checked = false;
            checkBoxMustehaklikBelgesiVerildimi.Checked = false;
            checkBoxKabulYazısıGetirildimi.Checked = false;
            checkBoxKimlikFotokopisiVerildimi.Checked = false;
            checkBoxStajDegerlendirmeFormu.Checked = false;
            checkBoxStajRaporu.Checked = false;
            comboBoxbasaiKontrol.SelectedIndex = -1;
        }


        private void buttonCikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
