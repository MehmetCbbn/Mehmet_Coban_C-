﻿namespace Bitirme_Projesi
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBoxSoru19 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru18 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru17 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru16 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru15 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru14 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru13 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru12 = new System.Windows.Forms.ComboBox();
            this.comboBoxSoru11 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxSoru10 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBoxSoru9 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBoxSoru8 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBoxSoru7 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBoxSoru6 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.comboBoxsoru5 = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.comboBoxSoru4 = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.comboBoxSoru3 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBoxsoru2 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBoxsoru1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxbasarıkontrol = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBoxsekilyazibicimdegerlendirmesi = new System.Windows.Forms.ComboBox();
            this.comboBoxislemdegerlendirmesi = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewOgrenciler = new System.Windows.Forms.DataGridView();
            this.labeltoplampuan = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.formtextstajyer = new System.Windows.Forms.Label();
            this.formtextstajbitis = new System.Windows.Forms.Label();
            this.formtextstajbaslangic = new System.Windows.Forms.Label();
            this.formtextemail = new System.Windows.Forms.Label();
            this.formtextno = new System.Windows.Forms.Label();
            this.formtextsinif = new System.Windows.Forms.Label();
            this.formtextad = new System.Windows.Forms.Label();
            this.pictureBoxogrenci = new System.Windows.Forms.PictureBox();
            this.buttonsil = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrenciler)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxogrenci)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Brown;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(11, 771);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(290, 59);
            this.button1.TabIndex = 0;
            this.button1.Text = "Çıkış";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(157, 644);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 59);
            this.button2.TabIndex = 1;
            this.button2.Text = "Kaydet";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(331, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(1176, 477);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Location = new System.Drawing.Point(25, 103);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(1132, 353);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comboBoxSoru19);
            this.groupBox6.Controls.Add(this.comboBoxSoru18);
            this.groupBox6.Controls.Add(this.comboBoxSoru17);
            this.groupBox6.Controls.Add(this.comboBoxSoru16);
            this.groupBox6.Controls.Add(this.comboBoxSoru15);
            this.groupBox6.Controls.Add(this.comboBoxSoru14);
            this.groupBox6.Controls.Add(this.comboBoxSoru13);
            this.groupBox6.Controls.Add(this.comboBoxSoru12);
            this.groupBox6.Controls.Add(this.comboBoxSoru11);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Location = new System.Drawing.Point(575, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(536, 317);
            this.groupBox6.TabIndex = 79;
            this.groupBox6.TabStop = false;
            // 
            // comboBoxSoru19
            // 
            this.comboBoxSoru19.FormattingEnabled = true;
            this.comboBoxSoru19.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxSoru19.Location = new System.Drawing.Point(269, 238);
            this.comboBoxSoru19.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru19.Name = "comboBoxSoru19";
            this.comboBoxSoru19.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru19.TabIndex = 104;
            // 
            // comboBoxSoru18
            // 
            this.comboBoxSoru18.FormattingEnabled = true;
            this.comboBoxSoru18.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.comboBoxSoru18.Location = new System.Drawing.Point(269, 213);
            this.comboBoxSoru18.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru18.Name = "comboBoxSoru18";
            this.comboBoxSoru18.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru18.TabIndex = 103;
            // 
            // comboBoxSoru17
            // 
            this.comboBoxSoru17.FormattingEnabled = true;
            this.comboBoxSoru17.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxSoru17.Location = new System.Drawing.Point(269, 188);
            this.comboBoxSoru17.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru17.Name = "comboBoxSoru17";
            this.comboBoxSoru17.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru17.TabIndex = 102;
            // 
            // comboBoxSoru16
            // 
            this.comboBoxSoru16.FormattingEnabled = true;
            this.comboBoxSoru16.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboBoxSoru16.Location = new System.Drawing.Point(269, 163);
            this.comboBoxSoru16.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru16.Name = "comboBoxSoru16";
            this.comboBoxSoru16.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru16.TabIndex = 101;
            // 
            // comboBoxSoru15
            // 
            this.comboBoxSoru15.FormattingEnabled = true;
            this.comboBoxSoru15.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBoxSoru15.Location = new System.Drawing.Point(269, 138);
            this.comboBoxSoru15.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru15.Name = "comboBoxSoru15";
            this.comboBoxSoru15.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru15.TabIndex = 100;
            // 
            // comboBoxSoru14
            // 
            this.comboBoxSoru14.FormattingEnabled = true;
            this.comboBoxSoru14.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
            this.comboBoxSoru14.Location = new System.Drawing.Point(269, 113);
            this.comboBoxSoru14.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru14.Name = "comboBoxSoru14";
            this.comboBoxSoru14.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru14.TabIndex = 99;
            // 
            // comboBoxSoru13
            // 
            this.comboBoxSoru13.FormattingEnabled = true;
            this.comboBoxSoru13.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxSoru13.Location = new System.Drawing.Point(269, 88);
            this.comboBoxSoru13.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru13.Name = "comboBoxSoru13";
            this.comboBoxSoru13.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru13.TabIndex = 98;
            // 
            // comboBoxSoru12
            // 
            this.comboBoxSoru12.FormattingEnabled = true;
            this.comboBoxSoru12.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboBoxSoru12.Location = new System.Drawing.Point(269, 63);
            this.comboBoxSoru12.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru12.Name = "comboBoxSoru12";
            this.comboBoxSoru12.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru12.TabIndex = 97;
            // 
            // comboBoxSoru11
            // 
            this.comboBoxSoru11.FormattingEnabled = true;
            this.comboBoxSoru11.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
            this.comboBoxSoru11.Location = new System.Drawing.Point(269, 37);
            this.comboBoxSoru11.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru11.Name = "comboBoxSoru11";
            this.comboBoxSoru11.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru11.TabIndex = 96;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.Brown;
            this.label22.Location = new System.Drawing.Point(336, 241);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 19);
            this.label22.TabIndex = 95;
            this.label22.Text = "3 Puan";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.Brown;
            this.label23.Location = new System.Drawing.Point(336, 215);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 19);
            this.label23.TabIndex = 94;
            this.label23.Text = "9 Puan";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.Brown;
            this.label24.Location = new System.Drawing.Point(336, 191);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(68, 19);
            this.label24.TabIndex = 93;
            this.label24.Text = "3 Puan";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.Brown;
            this.label25.Location = new System.Drawing.Point(336, 165);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(68, 19);
            this.label25.TabIndex = 92;
            this.label25.Text = "6 Puan";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.Brown;
            this.label26.Location = new System.Drawing.Point(336, 140);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(68, 19);
            this.label26.TabIndex = 91;
            this.label26.Text = "2 Puan";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.Brown;
            this.label27.Location = new System.Drawing.Point(336, 115);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(68, 19);
            this.label27.TabIndex = 90;
            this.label27.Text = "4 Puan";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.Brown;
            this.label28.Location = new System.Drawing.Point(336, 90);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 19);
            this.label28.TabIndex = 89;
            this.label28.Text = "3 Puan";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.Brown;
            this.label29.Location = new System.Drawing.Point(336, 65);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(68, 19);
            this.label29.TabIndex = 88;
            this.label29.Text = "6 Puan";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.Brown;
            this.label30.Location = new System.Drawing.Point(336, 39);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 19);
            this.label30.TabIndex = 87;
            this.label30.Text = "4 Puan";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(159, 241);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 19);
            this.label13.TabIndex = 86;
            this.label13.Text = "Soru 19";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(159, 215);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 19);
            this.label14.TabIndex = 85;
            this.label14.Text = "Soru 18";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(159, 191);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 19);
            this.label15.TabIndex = 84;
            this.label15.Text = "Soru 17";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(158, 165);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 19);
            this.label16.TabIndex = 83;
            this.label16.Text = "Soru 16";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(158, 140);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 19);
            this.label17.TabIndex = 82;
            this.label17.Text = "Soru 15";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(158, 115);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 19);
            this.label18.TabIndex = 81;
            this.label18.Text = "Soru 14";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(158, 90);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 19);
            this.label19.TabIndex = 80;
            this.label19.Text = "Soru 13";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(158, 65);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(74, 19);
            this.label20.TabIndex = 79;
            this.label20.Text = "Soru 12";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(159, 39);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 19);
            this.label21.TabIndex = 78;
            this.label21.Text = "Soru 11";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.comboBoxSoru10);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.comboBoxSoru9);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.comboBoxSoru8);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.comboBoxSoru7);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.comboBoxSoru6);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.comboBoxsoru5);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.comboBoxSoru4);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.comboBoxSoru3);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.comboBoxsoru2);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.comboBoxsoru1);
            this.groupBox5.Location = new System.Drawing.Point(18, 20);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(536, 317);
            this.groupBox5.TabIndex = 78;
            this.groupBox5.TabStop = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.ForeColor = System.Drawing.Color.Brown;
            this.label35.Location = new System.Drawing.Point(297, 153);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 19);
            this.label35.TabIndex = 46;
            this.label35.Text = "5 Puan";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(137, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 19);
            this.label3.TabIndex = 13;
            this.label3.Text = "Soru 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(136, 49);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 19);
            this.label4.TabIndex = 14;
            this.label4.Text = "Soru 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(136, 74);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 19);
            this.label5.TabIndex = 15;
            this.label5.Text = "Soru 3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(136, 101);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 19);
            this.label6.TabIndex = 16;
            this.label6.Text = "Soru 4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(136, 126);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 19);
            this.label7.TabIndex = 17;
            this.label7.Text = "Soru 5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(137, 153);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 19);
            this.label8.TabIndex = 18;
            this.label8.Text = "Soru 6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(136, 179);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 19);
            this.label11.TabIndex = 19;
            this.label11.Text = "Soru 7";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(136, 205);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 19);
            this.label10.TabIndex = 20;
            this.label10.Text = "Soru 8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(136, 232);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 19);
            this.label9.TabIndex = 21;
            this.label9.Text = "Soru 9";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(127, 258);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 19);
            this.label12.TabIndex = 22;
            this.label12.Text = "Soru 10";
            // 
            // comboBoxSoru10
            // 
            this.comboBoxSoru10.FormattingEnabled = true;
            this.comboBoxSoru10.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBoxSoru10.Location = new System.Drawing.Point(231, 256);
            this.comboBoxSoru10.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru10.Name = "comboBoxSoru10";
            this.comboBoxSoru10.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru10.TabIndex = 68;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.Brown;
            this.label40.Location = new System.Drawing.Point(297, 24);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 19);
            this.label40.TabIndex = 41;
            this.label40.Text = "3 Puan";
            // 
            // comboBoxSoru9
            // 
            this.comboBoxSoru9.FormattingEnabled = true;
            this.comboBoxSoru9.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboBoxSoru9.Location = new System.Drawing.Point(231, 231);
            this.comboBoxSoru9.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru9.Name = "comboBoxSoru9";
            this.comboBoxSoru9.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru9.TabIndex = 67;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.ForeColor = System.Drawing.Color.Brown;
            this.label39.Location = new System.Drawing.Point(297, 49);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(68, 19);
            this.label39.TabIndex = 42;
            this.label39.Text = "3 Puan";
            // 
            // comboBoxSoru8
            // 
            this.comboBoxSoru8.FormattingEnabled = true;
            this.comboBoxSoru8.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
            this.comboBoxSoru8.Location = new System.Drawing.Point(231, 203);
            this.comboBoxSoru8.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru8.Name = "comboBoxSoru8";
            this.comboBoxSoru8.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru8.TabIndex = 66;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.Brown;
            this.label38.Location = new System.Drawing.Point(297, 74);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(68, 19);
            this.label38.TabIndex = 43;
            this.label38.Text = "3 Puan";
            // 
            // comboBoxSoru7
            // 
            this.comboBoxSoru7.FormattingEnabled = true;
            this.comboBoxSoru7.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4"});
            this.comboBoxSoru7.Location = new System.Drawing.Point(231, 177);
            this.comboBoxSoru7.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru7.Name = "comboBoxSoru7";
            this.comboBoxSoru7.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru7.TabIndex = 65;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.ForeColor = System.Drawing.Color.Brown;
            this.label37.Location = new System.Drawing.Point(297, 99);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(68, 19);
            this.label37.TabIndex = 44;
            this.label37.Text = "2 Puan";
            // 
            // comboBoxSoru6
            // 
            this.comboBoxSoru6.FormattingEnabled = true;
            this.comboBoxSoru6.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBoxSoru6.Location = new System.Drawing.Point(231, 151);
            this.comboBoxSoru6.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru6.Name = "comboBoxSoru6";
            this.comboBoxSoru6.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru6.TabIndex = 64;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.ForeColor = System.Drawing.Color.Brown;
            this.label36.Location = new System.Drawing.Point(297, 126);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(68, 19);
            this.label36.TabIndex = 45;
            this.label36.Text = "3 Puan";
            // 
            // comboBoxsoru5
            // 
            this.comboBoxsoru5.FormattingEnabled = true;
            this.comboBoxsoru5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxsoru5.Location = new System.Drawing.Point(231, 124);
            this.comboBoxsoru5.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxsoru5.Name = "comboBoxsoru5";
            this.comboBoxsoru5.Size = new System.Drawing.Size(40, 21);
            this.comboBoxsoru5.TabIndex = 63;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.ForeColor = System.Drawing.Color.Brown;
            this.label34.Location = new System.Drawing.Point(297, 179);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(68, 19);
            this.label34.TabIndex = 47;
            this.label34.Text = "4 Puan";
            // 
            // comboBoxSoru4
            // 
            this.comboBoxSoru4.FormattingEnabled = true;
            this.comboBoxSoru4.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBoxSoru4.Location = new System.Drawing.Point(231, 99);
            this.comboBoxSoru4.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru4.Name = "comboBoxSoru4";
            this.comboBoxSoru4.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru4.TabIndex = 62;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.ForeColor = System.Drawing.Color.Brown;
            this.label33.Location = new System.Drawing.Point(297, 205);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(68, 19);
            this.label33.TabIndex = 48;
            this.label33.Text = "4 Puan";
            // 
            // comboBoxSoru3
            // 
            this.comboBoxSoru3.FormattingEnabled = true;
            this.comboBoxSoru3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxSoru3.Location = new System.Drawing.Point(231, 72);
            this.comboBoxSoru3.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSoru3.Name = "comboBoxSoru3";
            this.comboBoxSoru3.Size = new System.Drawing.Size(40, 21);
            this.comboBoxSoru3.TabIndex = 61;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.ForeColor = System.Drawing.Color.Brown;
            this.label32.Location = new System.Drawing.Point(297, 232);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(68, 19);
            this.label32.TabIndex = 49;
            this.label32.Text = "6 Puan";
            // 
            // comboBoxsoru2
            // 
            this.comboBoxsoru2.FormattingEnabled = true;
            this.comboBoxsoru2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxsoru2.Location = new System.Drawing.Point(231, 47);
            this.comboBoxsoru2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxsoru2.Name = "comboBoxsoru2";
            this.comboBoxsoru2.Size = new System.Drawing.Size(40, 21);
            this.comboBoxsoru2.TabIndex = 60;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label31.ForeColor = System.Drawing.Color.Brown;
            this.label31.Location = new System.Drawing.Point(297, 258);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 19);
            this.label31.TabIndex = 50;
            this.label31.Text = "2 Puan";
            // 
            // comboBoxsoru1
            // 
            this.comboBoxsoru1.FormattingEnabled = true;
            this.comboBoxsoru1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBoxsoru1.Location = new System.Drawing.Point(231, 22);
            this.comboBoxsoru1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxsoru1.Name = "comboBoxsoru1";
            this.comboBoxsoru1.Size = new System.Drawing.Size(40, 21);
            this.comboBoxsoru1.TabIndex = 13;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxbasarıkontrol);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.comboBoxsekilyazibicimdegerlendirmesi);
            this.groupBox2.Controls.Add(this.comboBoxislemdegerlendirmesi);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(25, 23);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(1132, 76);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // comboBoxbasarıkontrol
            // 
            this.comboBoxbasarıkontrol.FormattingEnabled = true;
            this.comboBoxbasarıkontrol.Items.AddRange(new object[] {
            "Başarısız",
            "Başarılı"});
            this.comboBoxbasarıkontrol.Location = new System.Drawing.Point(949, 36);
            this.comboBoxbasarıkontrol.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxbasarıkontrol.Name = "comboBoxbasarıkontrol";
            this.comboBoxbasarıkontrol.Size = new System.Drawing.Size(152, 21);
            this.comboBoxbasarıkontrol.TabIndex = 78;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.ForeColor = System.Drawing.Color.Brown;
            this.label48.Location = new System.Drawing.Point(819, 35);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(126, 19);
            this.label48.TabIndex = 13;
            this.label48.Text = "Staj Başarısı : ";
            // 
            // comboBoxsekilyazibicimdegerlendirmesi
            // 
            this.comboBoxsekilyazibicimdegerlendirmesi.FormattingEnabled = true;
            this.comboBoxsekilyazibicimdegerlendirmesi.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBoxsekilyazibicimdegerlendirmesi.Location = new System.Drawing.Point(240, 36);
            this.comboBoxsekilyazibicimdegerlendirmesi.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxsekilyazibicimdegerlendirmesi.Name = "comboBoxsekilyazibicimdegerlendirmesi";
            this.comboBoxsekilyazibicimdegerlendirmesi.Size = new System.Drawing.Size(152, 21);
            this.comboBoxsekilyazibicimdegerlendirmesi.TabIndex = 12;
            // 
            // comboBoxislemdegerlendirmesi
            // 
            this.comboBoxislemdegerlendirmesi.FormattingEnabled = true;
            this.comboBoxislemdegerlendirmesi.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxislemdegerlendirmesi.Location = new System.Drawing.Point(628, 36);
            this.comboBoxislemdegerlendirmesi.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxislemdegerlendirmesi.Name = "comboBoxislemdegerlendirmesi";
            this.comboBoxislemdegerlendirmesi.Size = new System.Drawing.Size(152, 21);
            this.comboBoxislemdegerlendirmesi.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Brown;
            this.label1.Location = new System.Drawing.Point(28, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 19);
            this.label1.TabIndex = 9;
            this.label1.Text = "İşyeri Değerlendirmesi : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Brown;
            this.label2.Location = new System.Drawing.Point(419, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 19);
            this.label2.TabIndex = 10;
            this.label2.Text = "Şekil- Biçim-Yazı Tipi : ";
            // 
            // dataGridViewOgrenciler
            // 
            this.dataGridViewOgrenciler.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridViewOgrenciler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOgrenciler.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridViewOgrenciler.Location = new System.Drawing.Point(331, 506);
            this.dataGridViewOgrenciler.Margin = new System.Windows.Forms.Padding(0);
            this.dataGridViewOgrenciler.Name = "dataGridViewOgrenciler";
            this.dataGridViewOgrenciler.RowHeadersWidth = 51;
            this.dataGridViewOgrenciler.RowTemplate.Height = 24;
            this.dataGridViewOgrenciler.Size = new System.Drawing.Size(1176, 344);
            this.dataGridViewOgrenciler.TabIndex = 4;
            this.dataGridViewOgrenciler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewOgrenciler_CellClick);
            // 
            // labeltoplampuan
            // 
            this.labeltoplampuan.Font = new System.Drawing.Font("Bookman Old Style", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labeltoplampuan.ForeColor = System.Drawing.Color.Brown;
            this.labeltoplampuan.Location = new System.Drawing.Point(5, 528);
            this.labeltoplampuan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labeltoplampuan.Name = "labeltoplampuan";
            this.labeltoplampuan.Size = new System.Drawing.Size(295, 32);
            this.labeltoplampuan.TabIndex = 5;
            this.labeltoplampuan.Text = "Staj Puanı : 0";
            this.labeltoplampuan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labeltoplampuan.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Yellow;
            this.button3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(10, 708);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(290, 58);
            this.button3.TabIndex = 6;
            this.button3.Text = "Sekretere Bildir";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonsil);
            this.groupBox4.Controls.Add(this.formtextstajyer);
            this.groupBox4.Controls.Add(this.formtextstajbitis);
            this.groupBox4.Controls.Add(this.formtextstajbaslangic);
            this.groupBox4.Controls.Add(this.labeltoplampuan);
            this.groupBox4.Controls.Add(this.formtextemail);
            this.groupBox4.Controls.Add(this.formtextno);
            this.groupBox4.Controls.Add(this.formtextsinif);
            this.groupBox4.Controls.Add(this.formtextad);
            this.groupBox4.Controls.Add(this.pictureBoxogrenci);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Location = new System.Drawing.Point(12, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(306, 835);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // formtextstajyer
            // 
            this.formtextstajyer.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextstajyer.Location = new System.Drawing.Point(6, 433);
            this.formtextstajyer.Name = "formtextstajyer";
            this.formtextstajyer.Size = new System.Drawing.Size(294, 72);
            this.formtextstajyer.TabIndex = 14;
            this.formtextstajyer.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // formtextstajbitis
            // 
            this.formtextstajbitis.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextstajbitis.Location = new System.Drawing.Point(6, 392);
            this.formtextstajbitis.Name = "formtextstajbitis";
            this.formtextstajbitis.Size = new System.Drawing.Size(294, 29);
            this.formtextstajbitis.TabIndex = 13;
            this.formtextstajbitis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formtextstajbaslangic
            // 
            this.formtextstajbaslangic.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextstajbaslangic.Location = new System.Drawing.Point(6, 354);
            this.formtextstajbaslangic.Name = "formtextstajbaslangic";
            this.formtextstajbaslangic.Size = new System.Drawing.Size(294, 29);
            this.formtextstajbaslangic.TabIndex = 12;
            this.formtextstajbaslangic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formtextemail
            // 
            this.formtextemail.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextemail.Location = new System.Drawing.Point(6, 314);
            this.formtextemail.Name = "formtextemail";
            this.formtextemail.Size = new System.Drawing.Size(294, 29);
            this.formtextemail.TabIndex = 11;
            this.formtextemail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formtextno
            // 
            this.formtextno.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextno.Location = new System.Drawing.Point(6, 284);
            this.formtextno.Name = "formtextno";
            this.formtextno.Size = new System.Drawing.Size(294, 23);
            this.formtextno.TabIndex = 10;
            this.formtextno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formtextsinif
            // 
            this.formtextsinif.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextsinif.Location = new System.Drawing.Point(6, 252);
            this.formtextsinif.Name = "formtextsinif";
            this.formtextsinif.Size = new System.Drawing.Size(294, 23);
            this.formtextsinif.TabIndex = 9;
            this.formtextsinif.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formtextad
            // 
            this.formtextad.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.formtextad.ForeColor = System.Drawing.SystemColors.ControlText;
            this.formtextad.Location = new System.Drawing.Point(6, 218);
            this.formtextad.Name = "formtextad";
            this.formtextad.Size = new System.Drawing.Size(294, 23);
            this.formtextad.TabIndex = 8;
            this.formtextad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxogrenci
            // 
            this.pictureBoxogrenci.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxogrenci.Image = global::Bitirme_Projesi.Properties.Resources.graduated;
            this.pictureBoxogrenci.Location = new System.Drawing.Point(47, 23);
            this.pictureBoxogrenci.Name = "pictureBoxogrenci";
            this.pictureBoxogrenci.Size = new System.Drawing.Size(208, 178);
            this.pictureBoxogrenci.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxogrenci.TabIndex = 8;
            this.pictureBoxogrenci.TabStop = false;
            this.pictureBoxogrenci.Visible = false;
            // 
            // buttonsil
            // 
            this.buttonsil.BackColor = System.Drawing.Color.Red;
            this.buttonsil.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonsil.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonsil.Location = new System.Drawing.Point(11, 644);
            this.buttonsil.Margin = new System.Windows.Forms.Padding(2);
            this.buttonsil.Name = "buttonsil";
            this.buttonsil.Size = new System.Drawing.Size(144, 59);
            this.buttonsil.TabIndex = 15;
            this.buttonsil.Text = "Sil";
            this.buttonsil.UseVisualStyleBackColor = false;
            this.buttonsil.Click += new System.EventHandler(this.buttonsil_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Bitirme_Projesi.Properties.Resources.backform2_new;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1516, 859);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.dataGridViewOgrenciler);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form3";
            this.Text = "Endüstri Mühendisliği Staj Değerlendirme Formu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrenciler)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxogrenci)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxsekilyazibicimdegerlendirmesi;
        private System.Windows.Forms.ComboBox comboBoxislemdegerlendirmesi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewOgrenciler;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBoxSoru10;
        private System.Windows.Forms.ComboBox comboBoxSoru9;
        private System.Windows.Forms.ComboBox comboBoxSoru8;
        private System.Windows.Forms.ComboBox comboBoxSoru7;
        private System.Windows.Forms.ComboBox comboBoxSoru6;
        private System.Windows.Forms.ComboBox comboBoxsoru5;
        private System.Windows.Forms.ComboBox comboBoxSoru4;
        private System.Windows.Forms.ComboBox comboBoxSoru3;
        private System.Windows.Forms.ComboBox comboBoxsoru2;
        private System.Windows.Forms.ComboBox comboBoxsoru1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxbasarıkontrol;
        private System.Windows.Forms.Label labeltoplampuan;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pictureBoxogrenci;
        private System.Windows.Forms.Label formtextad;
        private System.Windows.Forms.Label formtextemail;
        private System.Windows.Forms.Label formtextno;
        private System.Windows.Forms.Label formtextsinif;
        private System.Windows.Forms.Label formtextstajyer;
        private System.Windows.Forms.Label formtextstajbitis;
        private System.Windows.Forms.Label formtextstajbaslangic;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox comboBoxSoru19;
        private System.Windows.Forms.ComboBox comboBoxSoru18;
        private System.Windows.Forms.ComboBox comboBoxSoru17;
        private System.Windows.Forms.ComboBox comboBoxSoru16;
        private System.Windows.Forms.ComboBox comboBoxSoru15;
        private System.Windows.Forms.ComboBox comboBoxSoru14;
        private System.Windows.Forms.ComboBox comboBoxSoru13;
        private System.Windows.Forms.ComboBox comboBoxSoru12;
        private System.Windows.Forms.ComboBox comboBoxSoru11;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonsil;
    }
}